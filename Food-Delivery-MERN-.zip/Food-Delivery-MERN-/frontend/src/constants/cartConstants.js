export const ADD_TO_CART = "ADD_TO_CART";
export const UPDATE_CART_ITEM = "UPDATE_CART_ITEM";
export const REMOVE_ITEM_CART = "REMOVE_ITEM_CART";
export const FETCH_CART = "FETCH_CART";
export const CLEAR_CART = "CLEAR_CART";