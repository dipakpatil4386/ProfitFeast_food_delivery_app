# Recipe-Recommendation-Food-Recommendation-Python-Machine-Learning

This project implements a K-Nearest Neighbors (KNN) algorithm to recommend recipes based on user-inputted nutrients and ingredients. It also includes a Flask web application where users can type in their desired nutrients and ingredients to receive personalized recipe recommendations.
